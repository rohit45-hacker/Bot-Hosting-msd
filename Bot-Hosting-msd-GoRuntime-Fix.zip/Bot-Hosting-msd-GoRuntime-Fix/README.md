MSD Hosting Bot — Go runtime fix

WHY THIS FIX:
The decryption bot script is launched by hostingbot.py as a child Python process. Installing Go only in a separate service will not help; Go must exist in the same runtime/container that launches the script.

RENDER DEPLOY STEPS:
1. Commit these files to the GitHub repository connected to the hosting bot.
2. In Render, open the existing service's Settings. Change its runtime/environment to Docker (or create a Docker-based Background Worker/Web Service using this repo). Render must detect the root Dockerfile.
3. In Render -> Environment, set BOT_TOKEN to a newly regenerated token from @BotFather. Do not reuse the token previously hardcoded in the old source.
4. Keep the correct owner/admin IDs in hostingbot.py, or adjust them to your intended Telegram IDs.
5. Deploy and wait for the Docker image build to finish.
6. Restart the uploaded decryption bot script from the hosting bot after deployment. The old child process won't gain Go until it is restarted.

VERIFY:
In the Render logs, the Docker build should show golang-go installed. If decoding still fails, share the new full decoder error/log. This package adds Go to the hosting container; it does not guarantee every URI format is supported by Pantegnos.

SECURITY:
The previous source had a bot token hardcoded. Treat it as exposed and revoke/regenerate it with @BotFather. The patched hostingbot.py reads BOT_TOKEN from the Render environment instead.
